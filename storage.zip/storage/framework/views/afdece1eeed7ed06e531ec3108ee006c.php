

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow border-0">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                
                <div class="card-header bg-warning text-dark text-center">
                    <h5 class="mb-0">Edit User</h5>
                </div>

                
                <div class="card-body">

                    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="mb-3">
                            <label class="form-label">Nama</label>
                            <input type="text"
                                name="name"
                                class="form-control"
                                value="<?php echo e($user->name); ?>"
                                required>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email"
                                name="email"
                                class="form-control"
                                value="<?php echo e($user->email); ?>"
                                required>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label">
                                Password <small class="text-muted">(kosongkan jika tidak diubah)</small>
                            </label>

                            <div class="input-group">
                                <input type="password"
                                    name="password"
                                    id="password"
                                    class="form-control"
                                    placeholder="Isi jika ingin mengganti password">

                                <button type="button"
                                    class="btn btn-outline-secondary"
                                    onclick="togglePassword()">
                                    👁️
                                </button>
                            </div>
                        </div>

                        
                        <div class="mb-4">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-select">
                                <option value="admin" <?php echo e($user->role=='admin'?'selected':''); ?>>
                                    Admin
                                </option>
                                <option value="member" <?php echo e($user->role=='member'?'selected':''); ?>>
                                    Member
                                </option>
                            </select>
                        </div>

                        
                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('dashboard')); ?>"
                                class="btn btn-outline-secondary">
                                Kembali
                            </a>

                            <button class="btn btn-warning">
                                Update User
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>

</div>

<script>
    function togglePassword() {
        let input = document.getElementById('password');
        input.type = input.type === 'password' ? 'text' : 'password';
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daftar-peserta\resources\views/users/edit.blade.php ENDPATH**/ ?>