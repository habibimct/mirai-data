<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow fixed-top">

    <div class="container">

        
        <a class="navbar-brand fw-bold d-flex align-items-center" href="<?php echo e(route('dashboard')); ?>">

            <img src="<?php echo e(asset('LOGO_MIRAI.png')); ?>" alt="Logo" width="40" height="40"
                class="me-2 rounded-circle shadow-sm">

            <span>LPK Mirai</span>

        </a>

        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">

            <span class="navbar-toggler-icon"></span>
        </button>

        
        <div class="collapse navbar-collapse" id="navbarContent">

            
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active fw-bold' : ''); ?>"
                        href="<?php echo e(route('dashboard')); ?>">
                        Dashboard
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('participants.*') ? 'active fw-bold' : ''); ?>"
                        href="<?php echo e(route('participants.index')); ?>">
                        Peserta
                    </a>
                </li>

            </ul>

            
            <ul class="navbar-nav">

                <div class="d-flex align-items-center gap-3 me-3">

                    <a href="https://facebook.com/lpkmiraigresik?locale=id_ID" target="_blank" class="text-white fs-5">
                        <i class="bi bi-facebook text-white fs-5 social-icon"></i>
                    </a>

                    <a href="https://instagram.com/lpkmiraigresik/" target="_blank" class="text-white fs-5">
                        <i class="bi bi-instagram text-white fs-5 social-icon"></i>
                    </a>

                    <a href="https://youtube.com/@LPKMIRAIGRESIK" target="_blank" class="text-white fs-5">
                        <i class="bi bi-youtube text-white fs-5 social-icon"></i>
                    </a>

                    <a href="https://tiktok.com/@lpkmiraigresik" target="_blank" class="text-white fs-5">
                        <i class="bi bi-tiktok text-white fs-5 social-icon"></i>
                    </a>

                    <a href="https://wa.me/6281234567890" target="_blank" class="text-white fs-5">
                        <i class="bi bi-whatsapp text-white fs-5 social-icon"></i>
                    </a>

                </div>

                <li class="nav-item dropdown">

                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button"
                        data-bs-toggle="dropdown">

                        <div class="bg-white text-primary rounded-circle d-flex align-items-center justify-content-center me-2"
                            style="width:35px;height:35px;font-size:14px;">

                            <?php echo e(strtoupper(substr(Auth::user()->name, 0, 1))); ?>


                        </div>

                        <?php echo e(Auth::user()->name); ?>


                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3">

                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                                👤 Profile
                            </a>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <button type="submit" class="dropdown-item text-danger">
                                    🚪 Logout
                                </button>
                            </form>
                        </li>

                    </ul>

                </li>

            </ul>

        </div>

    </div>

    <style>
        .social-icon {
            transition: 0.3s;
        }

        .social-icon:hover {
            transform: translateY(-3px);
            opacity: 0.8;
        }
    </style>

</nav>
<?php /**PATH C:\xampp\htdocs\daftar-peserta\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>