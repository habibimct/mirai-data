

<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Daftar Peserta LPK Mirai Gresik</h2>

            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role == 'admin'): ?>
                    <a href="<?php echo e(route('participants.create')); ?>" class="btn btn-outline-success">
                        <i class="bi bi-person-plus-fill"></i> Tambah Peserta
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        
        <?php if($participants->isEmpty()): ?>
            <div class="alert alert-info text-center">
                Belum ada peserta terdaftar.
            </div>
        <?php endif; ?>

        <form method="GET" class="row g-2 mb-3">

            <div>
                <input type="text" name="search" class="form-control" placeholder="Cari nama..."
                    value="<?php echo e(request('search')); ?>">
            </div>

            <div class="col-md-4">
                <select name="qualification" class="form-control">
                    <option value="">-- Semua Kualifikasi --</option>

                    <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($filter); ?>" <?php echo e(request('qualification') == $filter ? 'selected' : ''); ?>>
                            <?php echo e($filter); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-2">
                <input type="number" name="age_min" class="form-control" placeholder="Umur min"
                    value="<?php echo e(request('age_min')); ?>">
            </div>

            <div class="col-md-2">
                <input type="number" name="age_max" class="form-control" placeholder="Umur max"
                    value="<?php echo e(request('age_max')); ?>">
            </div>

            <div class="col-md-2 d-grid">
                <button class="btn btn-outline-primary">Filter</button>
            </div>

            <div class="col-md-2 d-grid">
                <a href="<?php echo e(route('participants.index')); ?>" class="btn btn-outline-secondary">
                    Reset
                </a>
            </div>

        </form>

        <?php
            if (!function_exists('sortArrow')) {
                function sortArrow($field)
                {
                    return request('sort') == $field ? (request('direction') == 'asc' ? '↑' : '↓') : '';
                }
            }
        ?>

        
        <div class="table-responsive shadow-sm rounded">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th class="text-center">Foto</th>
                        <th>
                            <a
                                href="<?php echo e(request()->fullUrlWithQuery([
                                    'sort' => 'name',
                                    'direction' => request('direction') == 'asc' ? 'desc' : 'asc',
                                ])); ?>">
                                Nama<?php echo sortArrow('name'); ?>

                            </a>
                        </th>
                        <th>
                            <a
                                href="<?php echo e(request()->fullUrlWithQuery([
                                    'sort' => 'age',
                                    'direction' => request('direction') == 'asc' ? 'desc' : 'asc',
                                ])); ?>">
                                Usia<?php echo sortArrow('age'); ?>

                            </a>
                        </th>
                        <th>
                            <a
                                href="<?php echo e(request()->fullUrlWithQuery([
                                    'sort' => 'qualification',
                                    'direction' => request('direction') == 'asc' ? 'desc' : 'asc',
                                ])); ?>">
                                Kualifikasi<?php echo sortArrow('qualification'); ?>

                            </a>
                        </th>
                        <th>
                            <a
                                href="<?php echo e(request()->fullUrlWithQuery([
                                    'sort' => 'status',
                                    'direction' => request('direction') == 'asc' ? 'desc' : 'asc',
                                ])); ?>">
                                Status<?php echo sortArrow('status'); ?>

                            </a>
                        </th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>

                            
                            <td class="text-center">
                                <img src="<?php echo e($p->photo ? asset('storage/' . $p->photo) : asset('images/default-user.png')); ?>"
                                    class="rounded-circle shadow-sm" width="60" height="60"
                                    alt="Foto <?php echo e($p->name); ?>">
                            </td>

                            
                            <td class="fw-semibold text-capitalize"><?php echo e($p->name); ?></td>

                            
                            <td><?php echo e($p->age); ?> tahun</td>

                            
                            <td><?php echo e($p->qualification); ?></td>

                            
                            <td>
                                <?php if($p->status == 'Sending'): ?>
                                    <span class="badge bg-success">
                                        Sending
                                    </span>
                                <?php elseif($p->status == 'Existing'): ?>
                                    <span class="badge bg-primary">
                                        Existing
                                    </span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            
                            <td class="text-center">
                                <a href="<?php echo e(route('participants.show', $p->id)); ?>" class="btn btn-outline-primary btn-sm">
                                    <i class="bi bi-eye-fill">Detail</i>
                                </a>

                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->user()->role == 'admin'): ?>
                                        <a href="<?php echo e(route('participants.edit', $p->id)); ?>"
                                            class="btn btn-outline-warning btn-sm">
                                            <i class="bi bi-pencil-square">Edit</i>
                                        </a>

                                        <form action="<?php echo e(route('participants.destroy', $p->id)); ?>" method="POST"
                                            class="d-inline" onsubmit="return confirm('Yakin ingin menghapus peserta ini?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-outline-danger btn-sm">
                                                <i class="bi bi-trash-fill">Hapus</i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($participants->withQueryString()->links()); ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daftar-peserta\resources\views/participants/index.blade.php ENDPATH**/ ?>