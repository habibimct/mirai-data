<?php $__env->startSection('content'); ?>

<div class="container py-4">

    
    <div class="mb-4">
        <h2 class="fw-bold mb-1">Profile</h2>
        <p class="text-muted mb-0">
            Kelola informasi akun dan keamanan akun Anda.
        </p>
    </div>

    <div class="row g-4">

        
        <div class="col-lg-6">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-header bg-primary text-white rounded-top-4 py-3">
                    <h5 class="mb-0">
                        👤 Informasi Profile
                    </h5>
                </div>

                <div class="card-body p-4">

                    <div class="text-center mb-4">
                        <div class="bg-light rounded-circle d-inline-flex align-items-center justify-content-center"
                             style="width:90px;height:90px;font-size:35px;">
                            👤
                        </div>

                        <h5 class="mt-3 mb-1">
                            <?php echo e(auth()->user()->name); ?>

                        </h5>

                        <p class="text-muted">
                            <?php echo e(auth()->user()->email); ?>

                        </p>
                    </div>

                    <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>

        </div>

        
        <div class="col-lg-6">

            <div class="card border-0 shadow-sm rounded-4 mb-4">

                <div class="card-header bg-success text-white rounded-top-4 py-3">
                    <h5 class="mb-0">
                        🔒 Update Password
                    </h5>
                </div>

                <div class="card-body p-4">

                    <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>

            
            <div class="card border-0 shadow-sm rounded-4">

                <div class="card-header bg-danger text-white rounded-top-4 py-3">
                    <h5 class="mb-0">
                        🗑️ Hapus Akun
                    </h5>
                </div>

                <div class="card-body p-4">

                    <div class="alert alert-warning">
                        Hati-hati, akun yang dihapus tidak dapat dikembalikan.
                    </div>

                    <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daftar-peserta\resources\views/profile/edit.blade.php ENDPATH**/ ?>