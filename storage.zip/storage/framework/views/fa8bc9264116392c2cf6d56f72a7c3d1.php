<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="icon" type="image/png" href="<?php echo e(asset('LOGO_MIRAI.png')); ?>">
    
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
        }
    </style>
</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\daftar-peserta\resources\views/layouts/guest.blade.php ENDPATH**/ ?>