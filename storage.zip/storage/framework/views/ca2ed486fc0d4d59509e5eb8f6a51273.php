<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\daftar-peserta\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>