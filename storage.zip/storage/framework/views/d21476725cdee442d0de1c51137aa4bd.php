

<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        <form method="GET" action="<?php echo e(route('participants.show', $participant->id)); ?>" class="row g-2 mb-3">

            <div class="col-md-4">
                <select name="qualification" class="form-control">
                    <option value="">-- Semua Kualifikasi --</option>

                    <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($filter); ?>" <?php echo e(request('qualification') == $filter ? 'selected' : ''); ?>>
                            <?php echo e($filter); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-2">
                <input type="number" name="age_min" class="form-control" placeholder="Umur min"
                    value="<?php echo e(request('age_min')); ?>">
            </div>

            <div class="col-md-2">
                <input type="number" name="age_max" class="form-control" placeholder="Umur max"
                    value="<?php echo e(request('age_max')); ?>">
            </div>

            <div class="col-md-2 d-grid">
                <button class="btn btn-outline-primary">Filter</button>
            </div>

            <div class="col-md-2 d-grid">
                <a href="<?php echo e(route('participants.show', $participant->id)); ?>" class="btn btn-outline-secondary">
                    Reset
                </a>
            </div>

        </form>

        <div class="card shadow-sm">
            <div class="card-body">

                <div class="row">

                    
                    <div class="col-md-4 text-center">
                        <?php if($participant->photo): ?>
                            <img src="<?php echo e(asset('storage/' . $participant->photo)); ?>"
                                class="rounded shadow border d-block mx-auto"
                                style="width:250px;height:250px;object-fit:cover;">
                        <?php else: ?>
                            <div class="text-muted">Tidak ada foto</div>
                        <?php endif; ?>

                        <h4 class="mt-2"><?php echo e($participant->name); ?></h4>

                        <span class="badge bg-primary">
                            <?php echo e($participant->age ?? '-'); ?> Tahun
                        </span>
                    </div>

                    
                    <div class="col-md-8 border-1">

                        <h5 class="mb-2 mt-3 text-center fw-bold">Informasi Peserta</h5>

                        <hr>

                        <table class="table table-border">
                            <tr>
                                <th width="150">Tempat, Tgl Lahir</th>
                                <td>
                                    <?php echo e($participant->place_of_birth ?? '-'); ?>,
                                    <?php echo e(\Carbon\Carbon::parse($participant->date_of_birth)->translatedFormat('d F Y')); ?>

                                </td>
                            </tr>

                            <tr>
                                <th>Alamat</th>
                                <td><?php echo e($participant->address ?? '-'); ?></td>
                            </tr>

                            <tr>
                                <th>Kualifikasi</th>
                                <td><?php echo e($participant->qualification ?? '-'); ?></td>
                            </tr>

                            <tr>
                                <th>Status Peserta</th>
                                <td>
                                    <?php if($participant->status == 'Sending'): ?>
                                        <span class="badge bg-success">
                                            Sending
                                        </span>
                                    <?php elseif($participant->status == 'Existing'): ?>
                                        <span class="badge bg-primary">
                                            Existing
                                        </span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <th>Bahasa Jepang</th>
                                <td>
                                    <span class="badge bg-success">
                                        <?php echo e($participant->japanese_skills ?? '-'); ?>

                                    </span>
                                </td>
                            </tr>

                            <tr>
                                <th>Materi</th>
                                <td><?php echo e($participant->materials ?? '-'); ?></td>
                            </tr>

                            <tr>
                                <th>Motivasi</th>
                                <td><?php echo e($participant->motivation ?? '-'); ?></td>
                            </tr>

                            <tr>
                                <th>Visi</th>
                                <td><?php echo e($participant->vision ?? '-'); ?></td>
                            </tr>
                        </table>

                    </div>

                    <?php if($participant->youtube_link): ?>
                        <div class="mt-3">
                            <iframe width="100%" height="315" src="<?php echo e($participant->youtube_link); ?>" frameborder="0"
                                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen>
                            </iframe>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($participant->welding_photos): ?>
                        <div class="card shadow border-0 rounded-4 mt-4 overflow-hidden">

                            <div class="card-header bg-danger text-white py-2">
                                <h5 class="mb-0 fw-bold text-center">
                                    Hasil Las
                                </h5>
                            </div>

                            <div class="card-body bg-light">

                                <div class="row g-4">

                                    <?php $__currentLoopData = $participant->welding_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-6 col-md-4 col-lg-3">

                                            <div class="welding-card">

                                                <img src="<?php echo e(asset('storage/' . $photo)); ?>"
                                                    class="img-fluid rounded-4 shadow-sm border welding-image"
                                                    onclick="openImage(this.src)">

                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </div>
                        </div>

                        
                        <div id="imageViewer" class="image-viewer" onclick="closeImage()">

                            <span class="close-btn">&times;</span>

                            <img id="viewerImage">

                        </div>
                    <?php endif; ?>

                    
                    <div class="d-flex justify-content-between mt-4 mb-2">

                        
                        <?php if($previous): ?>
                            <a href="<?php echo e(route('participants.show', $previous->id)); ?>?<?php echo e(http_build_query(request()->all())); ?>"
                                class="btn btn-outline-primary">
                                Sebelumnya
                            </a>
                        <?php else: ?>
                            <span></span>
                        <?php endif; ?>

                        
                        <?php if($next): ?>
                            <a href="<?php echo e(route('participants.show', $next->id)); ?>?<?php echo e(http_build_query(request()->all())); ?>"
                                class="btn btn-outline-primary">
                                Berikutnya
                            </a>
                        <?php endif; ?>

                    </div>
                    <div class="d-flex justify-content-between">

                        <div class="">
                            <a href="<?php echo e(route('participants.index')); ?>" class="btn btn-outline-secondary">
                                Kembali
                            </a>
                        </div>

                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->role == 'admin'): ?>
                                <div class="">
                                    <a href="<?php echo e(route('participants.edit', $participant->id)); ?>"
                                        class="btn btn-outline-warning">
                                        Edit
                                    </a>

                                    <form action="<?php echo e(route('participants.destroy', $participant->id)); ?>" method="POST"
                                        class="d-inline" onsubmit="return confirm('Yakin hapus data?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button class="btn btn-outline-danger">
                                            Hapus
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>

                </div>

            </div>
        </div>

    </div>

    

    
    <style>
        .welding-card {
            overflow: hidden;
            border-radius: 20px;
        }

        .welding-image {
            width: 100%;
            height: 220px;
            object-fit: cover;
            cursor: pointer;
            transition: .3s;
        }

        .welding-image:hover {
            transform: scale(1.05);
            filter: brightness(0.8);
        }

        /* FULLSCREEN VIEWER */
        .image-viewer {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.9);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            padding: 30px;
        }

        .image-viewer img {
            max-width: 95%;
            max-height: 95%;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
            animation: zoomIn .2s ease;
        }

        .close-btn {
            position: absolute;
            top: 20px;
            right: 35px;
            font-size: 45px;
            color: white;
            cursor: pointer;
        }

        @keyframes zoomIn {
            from {
                transform: scale(.8);
                opacity: 0;
            }

            to {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>

    

    
    <script>
        function openImage(src) {

            document.getElementById('viewerImage').src = src;

            document.getElementById('imageViewer').style.display = 'flex';
        }

        function closeImage() {

            document.getElementById('imageViewer').style.display = 'none';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daftar-peserta\resources\views/participants/show.blade.php ENDPATH**/ ?>