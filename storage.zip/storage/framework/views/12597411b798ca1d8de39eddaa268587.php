

<?php $__env->startSection('content'); ?>
    <div class="container py-4">

        <div class="card shadow-sm">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0">Edit Peserta</h5>
            </div>

            <div class="card-body">

                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('participants.update', $participant->id)); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row">

                        
                        <div class="col-md-6">

                            <div class="mb-3">
                                <label class="form-label">Nama</label>
                                <input type="text" name="name" value="<?php echo e(old('name', $participant->name)); ?>"
                                    class="form-control" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Tempat Lahir</label>
                                <input type="text" name="place_of_birth"
                                    value="<?php echo e(old('place_of_birth', $participant->place_of_birth)); ?>" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Tanggal Lahir</label>
                                <input type="date" name="date_of_birth"
                                    value="<?php echo e(old('date_of_birth', $participant->date_of_birth)); ?>" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Kualifikasi</label>
                                <input type="text" name="qualification"
                                    value="<?php echo e(old('qualification', $participant->qualification)); ?>" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Status Peserta</label>

                                <select name="status" class="form-select">
                                    <option value="">-- Pilih Status --</option>

                                    <option value="Sending" <?php echo e($participant->status == 'Sending' ? 'selected' : ''); ?>>
                                        Sending
                                    </option>

                                    <option value="Existing" <?php echo e($participant->status == 'Existing' ? 'selected' : ''); ?>>
                                        Existing
                                    </option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Bahasa Jepang</label>
                                <input type="text" name="japanese_skills"
                                    value="<?php echo e(old('japanese_skills', $participant->japanese_skills)); ?>"
                                    class="form-control">
                            </div>

                            
                            <div class="mb-3">
                                <label class="form-label">Foto Saat Ini</label><br>

                                <?php if($participant->photo): ?>
                                    <img src="<?php echo e(asset('storage/' . $participant->photo)); ?>" width="120"
                                        class="rounded border">
                                <?php else: ?>
                                    <p class="text-muted">Belum ada foto</p>
                                <?php endif; ?>
                            </div>

                            
                            <div class="mb-3">
                                <label class="form-label">Ganti Foto</label>
                                <input type="file" name="photo" class="form-control">
                                <img id="preview" class="mt-2 d-none rounded" width="120">
                            </div>

                        </div>

                        
                        <div class="col-md-6">

                            <div class="mb-3">
                                <label class="form-label">Alamat</label>
                                <textarea name="address" class="form-control" rows="3"><?php echo e(old('address', $participant->address)); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Materi</label>
                                <textarea name="materials" class="form-control" rows="2"><?php echo e(old('materials', $participant->materials)); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Motivasi</label>
                                <textarea name="motivation" class="form-control" rows="2"><?php echo e(old('motivation', $participant->motivation)); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Visi</label>
                                <textarea name="vision" class="form-control" rows="2"><?php echo e(old('vision', $participant->vision)); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Link YouTube</label>
                                <input type="url" name="youtube_link" id="youtube_link" class="form-control"
                                    placeholder="https://youtube.com/...">

                                <div class="mt-3">
                                    <iframe id="youtube_preview" class="w-100 d-none" height="250" frameborder="0"
                                        allowfullscreen>
                                    </iframe>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold fs-5">
                                    Hasil Las
                                </label>

                                
                                <input type="file" name="welding_photos[]" class="form-control mb-4" multiple
                                    accept="image/*">

                                
                                <?php if($participant->welding_photos): ?>
                                    <div class="row g-4">

                                        <?php $__currentLoopData = $participant->welding_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-6 col-md-4 col-lg-3">

                                                <div class="gallery-card">

                                                    
                                                    <input type="checkbox" name="delete_photos[]"
                                                        value="<?php echo e($photo); ?>" id="delete<?php echo e($index); ?>"
                                                        class="d-none delete-checkbox">

                                                    
                                                    <img src="<?php echo e(asset('storage/' . $photo)); ?>" class="gallery-image">

                                                    
                                                    <label for="delete<?php echo e($index); ?>" class="delete-btn">

                                                        &times;

                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>

                    
                    <div class="d-flex justify-content-between mt-3">
                        <a href="<?php echo e(route('participants.index')); ?>" class="btn btn-secondary">
                            Kembali
                        </a>

                        <button type="submit" class="btn btn-warning">
                            Update Data
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    

    <style>
        .gallery-card {
            position: relative;
            overflow: hidden;
            border-radius: 20px;
            background: #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, .08);
            transition: .3s;
        }

        .gallery-card:hover {
            transform: translateY(-5px);
        }

        .gallery-image {
            width: 100%;
            height: 230px;
            object-fit: cover;
            display: block;
            transition: .3s;
        }

        .gallery-image:hover {
            transform: scale(1.05);
        }

        .delete-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: rgba(220, 53, 69, .95);
            color: white;
            font-size: 24px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: .2s;
            z-index: 10;
        }

        .delete-btn:hover {
            background: #dc3545;
            transform: scale(1.1);
        }

        /* Efek saat dipilih hapus */
        .delete-checkbox:checked~.gallery-image {
            opacity: .25;
            filter: grayscale(100%);
            transform: scale(.95);
        }

        .delete-checkbox:checked~.delete-btn {
            background: black;
        }
    </style>

    

    
    <script>
        document.querySelector('input[name="photo"]').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const preview = document.getElementById('preview');

            if (file) {
                preview.src = URL.createObjectURL(file);
                preview.classList.remove('d-none');
            }
        });
    </script>

    
    <script>
        document.getElementById('youtube_link').addEventListener('input', function() {
            let url = this.value;
            let iframe = document.getElementById('youtube_preview');

            if (!url) {
                iframe.classList.add('d-none');
                return;
            }

            // Ambil ID video
            let videoId = null;

            if (url.includes("watch?v=")) {
                videoId = url.split("v=")[1].split("&")[0];
            } else if (url.includes("youtu.be/")) {
                videoId = url.split("youtu.be/")[1];
            }

            if (videoId) {
                iframe.src = "https://www.youtube.com/embed/" + videoId;
                iframe.classList.remove('d-none');
            } else {
                iframe.classList.add('d-none');
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\daftar-peserta\resources\views/participants/edit.blade.php ENDPATH**/ ?>